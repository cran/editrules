#' Some example editrules
#'
#' 
#' @title Example editrules, used in vignette
#' @usage data(edits)
#' @name edits
#' @docType data
#' @keywords data
{}


