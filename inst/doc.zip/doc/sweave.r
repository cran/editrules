options(error=traceback)
Sweave("editrules-linear.Rnw")
Sweave("editrules-categorical.Rnw")



