
Sweave("editrules-linear.Snw")
Sweave("editrules-categorical.Snw")



